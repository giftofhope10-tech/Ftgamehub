import { EventData, Page, PanGestureEventData, TouchGestureEventData, View } from '@nativescript/core';
import { GameViewModel } from './main-view-model';

let vm: GameViewModel;

export function navigatingTo(args: EventData) {
  const page = <Page>args.object;
  vm = new GameViewModel();
  page.bindingContext = vm;

  setTimeout(() => {
    const arena = page.getViewById('arena') as View;
    if (arena) {
      const w = arena.getMeasuredWidth();
      const h = arena.getMeasuredHeight();
      vm.setArenaSize(w, h);
    }
  }, 400);
}

export function onStart(args: EventData) {
  vm.startGame();
}

export function onRestart(args: EventData) {
  vm.startGame();
}

export function onArenaPan(args: PanGestureEventData) {
  if (!vm.isPlaying) return;
  vm.moveBasketByPx(args.deltaX);
}

export function onArenaTouch(args: TouchGestureEventData) {
  if (!vm.isPlaying) return;
  const x = args.getX();
  vm.setBasketX(x);
}
