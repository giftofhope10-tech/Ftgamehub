import { Observable, ObservableArray } from '@nativescript/core';

export interface FruitItem {
  id: number;
  emoji: string;
  isBomb: boolean;
  leftPx: number; // pixels from left
  topPx: number; // pixels from top
  speed: number; // pixels per tick
  rotation: number;
}

const FRUITS = ['🍎', '🍊', '🍌', '🍇', '🍉', '🍓', '🥝', '🥭', '🍑', '🍍'];
const BOMB = '💣';
const BOMB_CHANCE = 0.18;
const BASE_SPEED = 6;
const SPEED_INCREMENT = 0.15;
const SPAWN_INTERVAL = 650; // ms
const TICK_MS = 16;
const FRUIT_SIZE = 48;
const BASKET_SIZE = 72;

export class GameViewModel extends Observable {
  private _score = 0;
  private _lives = 3;
  private _best = 0;
  private _basketLeftPx = 0; // pixels
  private _isPlaying = false;
  private _isGameOver = false;
  private _gameTime = 0;

  fruits: ObservableArray<FruitItem> = new ObservableArray();
  private nextId = 1;
  private tickTimer: any;
  private spawnTimer: any;
  private elapsed = 0;
  private currentSpeed = BASE_SPEED;
  private arenaWidth = 360;
  private arenaHeight = 600;

  constructor() {
    super();
    this.loadBest();
  }

  get score(): number { return this._score; }
  set score(v: number) {
    if (this._score !== v) { this._score = v; this.notifyPropertyChange('score', v); }
  }

  get lives(): number { return this._lives; }
  set lives(v: number) {
    if (this._lives !== v) { this._lives = v; this.notifyPropertyChange('lives', v); }
  }

  get best(): number { return this._best; }
  set best(v: number) {
    if (this._best !== v) { this._best = v; this.notifyPropertyChange('best', v); }
  }

  get basketLeftPx(): number { return this._basketLeftPx; }
  set basketLeftPx(v: number) {
    const clamped = Math.max(0, Math.min(this.arenaWidth - BASKET_SIZE, v));
    if (this._basketLeftPx !== clamped) { this._basketLeftPx = clamped; this.notifyPropertyChange('basketLeftPx', clamped); }
  }

  get basketTopPx(): number {
    return Math.max(0, this.arenaHeight - BASKET_SIZE - 10);
  }

  get isPlaying(): boolean { return this._isPlaying; }
  set isPlaying(v: boolean) {
    if (this._isPlaying !== v) { this._isPlaying = v; this.notifyPropertyChange('isPlaying', v); }
  }

  get isGameOver(): boolean { return this._isGameOver; }
  set isGameOver(v: boolean) {
    if (this._isGameOver !== v) { this._isGameOver = v; this.notifyPropertyChange('isGameOver', v); }
  }

  get gameTime(): number { return this._gameTime; }
  set gameTime(v: number) {
    if (this._gameTime !== v) { this._gameTime = v; this.notifyPropertyChange('gameTime', v); }
  }

  private loadBest() {
    try {
      const stored = this.readStorage('fruit_catch_best');
      if (stored) this.best = parseInt(stored, 10) || 0;
    } catch (e) { /* ignore */ }
  }

  private saveBest() {
    try { this.writeStorage('fruit_catch_best', String(this.best)); } catch (e) { /* ignore */ }
  }

  private readStorage(key: string): string {
    try {
      const app = require('@nativescript/core').Application;
      const ctx = app.android.context;
      if (!ctx) return '';
      const prefs = ctx.getSharedPreferences('fruit_catch', 0);
      return prefs.getString(key, '');
    } catch (e) { return ''; }
  }

  private writeStorage(key: string, value: string) {
    try {
      const app = require('@nativescript/core').Application;
      const ctx = app.android.context;
      if (!ctx) return;
      const prefs = ctx.getSharedPreferences('fruit_catch', 0).edit();
      prefs.putString(key, value);
      prefs.commit();
    } catch (e) { /* ignore */ }
  }

  setArenaSize(w: number, h: number) {
    this.arenaWidth = w || 360;
    this.arenaHeight = h || 600;
    this.notifyPropertyChange('basketTopPx', this.basketTopPx);
  }

  startGame() {
    this.score = 0;
    this.lives = 3;
    this.basketLeftPx = this.arenaWidth / 2 - BASKET_SIZE / 2;
    this.isGameOver = false;
    this.isPlaying = true;
    this.elapsed = 0;
    this.currentSpeed = BASE_SPEED;
    this.gameTime = 0;
    this.fruits.splice(0, this.fruits.length);

    this.tickTimer = setInterval(() => this.tick(), TICK_MS);
    this.spawnTimer = setInterval(() => this.spawnFruit(), SPAWN_INTERVAL);
  }

  endGame() {
    this.isPlaying = false;
    this.isGameOver = true;
    if (this.tickTimer) { clearInterval(this.tickTimer); this.tickTimer = null; }
    if (this.spawnTimer) { clearInterval(this.spawnTimer); this.spawnTimer = null; }
    if (this.score > this.best) {
      this.best = this.score;
      this.saveBest();
    }
  }

  moveBasketByPx(deltaPx: number) {
    this.basketLeftPx = this._basketLeftPx + deltaPx;
  }

  setBasketX(xPx: number) {
    this.basketLeftPx = xPx - BASKET_SIZE / 2;
  }

  private spawnFruit() {
    const isBomb = Math.random() < BOMB_CHANCE;
    const emoji = isBomb ? BOMB : FRUITS[Math.floor(Math.random() * FRUITS.length)];
    const fruit: FruitItem = {
      id: this.nextId++,
      emoji,
      isBomb,
      leftPx: Math.random() * (this.arenaWidth - FRUIT_SIZE),
      topPx: -FRUIT_SIZE,
      speed: this.currentSpeed + Math.random() * 3,
      rotation: Math.random() * 60 - 30,
    };
    this.fruits.push(fruit);
  }

  private tick() {
    this.elapsed += TICK_MS;
    this.gameTime = Math.floor(this.elapsed / 1000);
    this.currentSpeed = BASE_SPEED + this.elapsed / 1000 * SPEED_INCREMENT;

    const basketTop = this.arenaHeight - BASKET_SIZE - 10;
    const catchZoneTop = basketTop - 30;
    const basketCenter = this._basketLeftPx + BASKET_SIZE / 2;

    const toRemove: number[] = [];
    for (let i = 0; i < this.fruits.length; i++) {
      const f = this.fruits.getItem(i);
      f.topPx += f.speed;
      f.rotation += 2;

      const fruitCenter = f.leftPx + FRUIT_SIZE / 2;
      const horizontalDist = Math.abs(fruitCenter - basketCenter);

      // catch detection
      if (f.topPx >= catchZoneTop && f.topPx <= basketTop + 20 && horizontalDist < BASKET_SIZE / 2 + 8) {
        if (f.isBomb) {
          this.lives -= 1;
          toRemove.push(i);
          if (this.lives <= 0) { this.endGame(); break; }
        } else {
          this.score += 10;
          toRemove.push(i);
        }
        continue;
      }

      // missed (fell past bottom)
      if (f.topPx > this.arenaHeight) {
        if (!f.isBomb) {
          this.lives -= 1;
          toRemove.push(i);
          if (this.lives <= 0) { this.endGame(); break; }
        } else {
          toRemove.push(i);
        }
      }
    }

    for (let i = toRemove.length - 1; i >= 0; i--) {
      this.fruits.splice(toRemove[i], 1);
    }

    this.notifyPropertyChange('fruits', this.fruits);
  }
}
